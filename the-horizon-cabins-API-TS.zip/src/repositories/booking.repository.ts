import { prisma } from "../config/database.js";
import { Prisma } from "../generated/prisma/client.js";
import type { Booking, BookingStatus, CancellationReason } from "../generated/prisma/client.js";

const ACTIVE_BOOKING_STATUSES: BookingStatus[] = [
  "pending",
  "confirmed",
  "checkedIn",
  "checkedOut",
];

export interface BookingFilters {
  status?: BookingStatus;
  cabinId?: number;
  guestId?: number;
  startDateFrom?: Date;
  startDateTo?: Date;
}

export interface FindAllBookingsParams {
  skip: number;
  limit: number;
  filters: BookingFilters;
}

function buildWhereClause(filters: BookingFilters): Prisma.BookingWhereInput {
  const where: Prisma.BookingWhereInput = {};

  if (filters.status) where.status = filters.status;
  if (filters.cabinId !== undefined) where.cabinId = filters.cabinId;
  if (filters.guestId !== undefined) where.guestId = filters.guestId;
  if (filters.startDateFrom || filters.startDateTo) {
    where.startDate = {};
    if (filters.startDateFrom) where.startDate.gte = filters.startDateFrom;
    if (filters.startDateTo) where.startDate.lte = filters.startDateTo;
  }

  return where;
}

export async function findAllBookings({ skip, limit, filters }: FindAllBookingsParams) {
  const where = buildWhereClause(filters);
  const [data, total] = await Promise.all([
    prisma.booking.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: "desc" },
      include: {
        cabin: { select: { id: true, name: true } },
        guest: { select: { id: true, fullName: true } },
      },
    }),
    prisma.booking.count({ where }),
  ]);
  return { data, total };
}

export async function findBookingById(id: number): Promise<Booking | null> {
  return prisma.booking.findUnique({ where: { id } });
}

export async function findOverlappingBooking(
  cabinId: number,
  startDate: Date,
  endDate: Date,
): Promise<Booking | null> {
  return prisma.booking.findFirst({
    where: {
      cabinId,
      status: { in: ACTIVE_BOOKING_STATUSES },
      startDate: { lt: endDate },
      endDate: { gt: startDate },
    },
  });
}

export async function countPendingBookingsForGuest(guestId: number): Promise<number> {
  return prisma.booking.count({
    where: { guestId, status: "pending" },
  });
}

export async function createBooking(data: Prisma.BookingCreateInput): Promise<Booking> {
  return prisma.booking.create({ data });
}

export async function updateBooking(id: number, data: Prisma.BookingUpdateInput): Promise<Booking> {
  return prisma.booking.update({ where: { id }, data });
}

export async function expirePendingBookings(now: Date): Promise<number> {
  const result = await prisma.booking.updateMany({
    where: { status: "pending", paymentDeadline: { lt: now } },
    data: {
      status: "cancelled",
      cancelledAt: now,
      cancellationReason: "paymentExpired" as CancellationReason,
    },
  });
  return result.count;
}
