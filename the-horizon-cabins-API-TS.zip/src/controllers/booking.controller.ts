import type { Request, Response } from "express";
import * as bookingService from "../services/booking.service.js";
import * as guestRepository from "../repositories/guest.repository.js";
import { sendSuccess } from "../utils/apiResponse.js";
import type { BookingFilters } from "../repositories/booking.repository.js";
import { AppError } from "../utils/AppError.js";
import { ErrorCode } from "../constants/errorCodes.js";
import { HTTP_STATUS } from "../constants/httpStatus.js";

export async function create(req: Request, res: Response): Promise<void> {
  const guest = await guestRepository.findGuestByUserId(req.user!.id);
  if (!guest) {
    throw new AppError("Guest profile not found", HTTP_STATUS.FORBIDDEN, ErrorCode.FORBIDDEN);
  }
  const booking = await bookingService.createBooking(req.body, guest.id);
  res.status(201).json({ status: "success", data: { booking } });
}

export async function getAll(req: Request, res: Response): Promise<void> {
  const { skip, limit, page } = req.pagination!;
  const { parseQuery } = req;
  const query = parseQuery as Record<string, unknown>;

  const filters: BookingFilters = {};
  if (query.status) filters.status = query.status as BookingFilters["status"];
  if (query.cabinId) filters.cabinId = query.cabinId as number;
  if (query.guestId) filters.guestId = query.guestId as number;
  if (query.startDateFrom) filters.startDateFrom = query.startDateFrom as Date;
  if (query.startDateTo) filters.startDateTo = query.startDateTo as Date;

  const isAdmin = req.user!.role === "admin";
  const guest = await guestRepository.findGuestByUserId(req.user!.id);

  const { data: bookings, meta } = await bookingService.getAllBookings({
    skip,
    limit,
    page,
    filters,
    isAdmin,
    guestId: guest?.id,
  });

  sendSuccess(res, { data: { bookings, meta } });
}

export async function getById(req: Request, res: Response): Promise<void> {
  const id = Number(req.params.id);
  const isAdmin = req.user!.role === "admin";
  const booking = await bookingService.getBookingById(id, req.user!.id, isAdmin);
  sendSuccess(res, { data: { booking } });
}

export async function pay(req: Request, res: Response): Promise<void> {
  const id = Number(req.params.id);
  const booking = await bookingService.payBooking(id, req.user!.id);
  sendSuccess(res, { data: { booking } });
}

export async function cancel(req: Request, res: Response): Promise<void> {
  const id = Number(req.params.id);
  const booking = await bookingService.cancelBooking(id, req.user!.id);
  sendSuccess(res, { data: { booking } });
}

export async function updateStatus(req: Request, res: Response): Promise<void> {
  const id = Number(req.params.id);
  const booking = await bookingService.updateBookingStatus(id, req.body);
  sendSuccess(res, { data: { booking } });
}
