import { z } from "zod";
import { safeNumber } from "../utils/safeParseNumber.js";

const idParamsSchema = z.object({
  id: z.string().regex(/^\d+$/, { message: "ID must be a number" }).transform(Number),
});

const createBookingBodySchema = z.object({
  cabinId: z.preprocess(safeNumber, z.number().int().positive()),
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
  numGuests: z.preprocess(safeNumber, z.number().int().min(1)),
  observations: z.string().trim().max(2000).optional(),
});

const listBookingsQuerySchema = z.object({
  status: z.enum(["pending", "confirmed", "cancelled", "checkedIn", "checkedOut"]).optional(),
  cabinId: z.preprocess(safeNumber, z.number().int().positive().optional()),
  guestId: z.preprocess(safeNumber, z.number().int().positive().optional()),
  startDateFrom: z.coerce.date().optional(),
  startDateTo: z.coerce.date().optional(),
});

const updateStatusBodySchema = z.object({
  status: z.enum(["checkedIn", "checkedOut"]),
});

export const createBookingSchema = { body: createBookingBodySchema };
export const listBookingsQueryValidation = { query: listBookingsQuerySchema };
export const getBookingSchema = { params: idParamsSchema };
export const payBookingSchema = { params: idParamsSchema };
export const cancelBookingSchema = { params: idParamsSchema };
export const updateBookingStatusSchema = { params: idParamsSchema, body: updateStatusBodySchema };
